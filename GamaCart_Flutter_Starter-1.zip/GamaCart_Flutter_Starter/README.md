# GamaCart Flutter starter

Includes a red G brand, product browse/search, category chips, cart, checkout screen, login/signup integration scaffold, order tracking placeholder, and admin-role guidance.

## Run
1. Install Flutter and Android Studio.
2. Run `flutter pub get`.
3. Set up a Firebase project and run `flutterfire configure`.
4. Add generated Firebase options, then uncomment Firebase initialization in `lib/main.dart`.
5. Enable Email/Password in Firebase Authentication and configure secure Firestore rules.
6. Run `flutter run`.

## Before launch
This is a starter project, not a production-ready store. Add Firestore-backed catalog/orders, secure admin custom claims, server-side payment verification (Razorpay), real image upload, address validation, order state updates, privacy policy, and testing. Never put payment secret keys in the mobile app.
