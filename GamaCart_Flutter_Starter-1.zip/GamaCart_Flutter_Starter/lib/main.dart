import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

const red = Color(0xFFE32636);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // After running `flutterfire configure`, uncomment:
  // await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const GamaCart());
}

class GamaCart extends StatelessWidget {
  const GamaCart({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'GamaCart', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: red), useMaterial3: true),
    home: const StorePage());
}

class Item {
  final String name, category, image;
  final int price;
  const Item(this.name, this.category, this.image, this.price);
}
const items = [
  Item('Headphones','Electronics','https://images.unsplash.com/photo-150', 1499),
  Item('Smart Watch','Electronics','https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=500&q=80',1999),
  Item('Backpack','Fashion','https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=500&q=80',899),
  Item('Sneakers','Fashion','https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=500&q=80',1799),
];

class StorePage extends StatefulWidget {
  const StorePage({super.key});
  @override State<StorePage> createState()=>_StorePageState();
}
class _StorePageState extends State<StorePage> {
  final cart = <int,int>{}; String query='', category='All';
  int get count=>cart.values.fold(0,(a,b)=>a+b);
  int get total=>cart.entries.fold(0,(s,e)=>s+items[e.key].price*e.value);
  @override Widget build(BuildContext context) {
    final shown=List.generate(items.length,(i)=>i).where((i)=>
      (category=='All'||items[i].category==category)&&items[i].name.toLowerCase().contains(query.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: Row(children:[
        Container(width:38,height:38,alignment:Alignment.center,decoration:BoxDecoration(color:red,borderRadius:BorderRadius.circular(10)),
          child:const Text('G',style:TextStyle(color:Colors.white,fontSize:25,fontWeight:FontWeight.w900))),
        const SizedBox(width:8),const Text('GamaCart',style:TextStyle(fontWeight:FontWeight.bold))
      ]),actions:[IconButton(onPressed:()=>showCart(context),icon:Badge(label:Text('$count'),child:const Icon(Icons.shopping_cart))) ]),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(color:const Color(0xFFFFE8EA),borderRadius:BorderRadius.circular(18)),
          child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('Shop smart.',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),
            Text('Live better.',style:TextStyle(fontSize:30,color:red,fontWeight:FontWeight.w900)),
            Text('Discover deals at GamaCart.')
          ])),
        const SizedBox(height:14),
        TextField(onChanged:(v)=>setState(()=>query=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search products',border:OutlineInputBorder())),
        Wrap(spacing:8,children:['All','Electronics','Fashion'].map((c)=>ChoiceChip(label:Text(c),selected:category==c,onSelected:(_)=>setState(()=>category=c))).toList()),
        const Text('Featured products',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:shown.length,
          gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:.68,crossAxisSpacing:12,mainAxisSpacing:12),
          itemBuilder:(_,n){final i=shown[n];final p=items[i];return Card(clipBehavior:Clip.antiAlias,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Expanded(child:Image.network(p.image,fit:BoxFit.cover,width:double.infinity,errorBuilder:(_,__,___)=>const Icon(Icons.shopping_bag,size:60,color:red))),
            Padding(padding:const EdgeInsets.all(8),child:Text(p.name,style:const TextStyle(fontWeight:FontWeight.bold))),
            Padding(padding:const EdgeInsets.symmetric(horizontal:8),child:Text('₹${p.price}')),
            Padding(padding:const EdgeInsets.all(8),child:FilledButton(style:FilledButton.styleFrom(backgroundColor:red),
              onPressed:()=>setState(()=>cart.update(i,(v)=>v+1,ifAbsent:()=>1)),child:const Text('Add to cart')))
          ]));}),
      ]),
      bottomNavigationBar:NavigationBar(destinations:const[
        NavigationDestination(icon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.category),label:'Categories'),
        NavigationDestination(icon:Icon(Icons.local_shipping),label:'Orders'),
        NavigationDestination(icon:Icon(Icons.person),label:'Account')],
        onDestinationSelected:(i){if(i==2)Navigator.push(context,MaterialPageRoute(builder:(_)=>const OrdersPage()));if(i==3)Navigator.push(context,MaterialPageRoute(builder:(_)=>const AuthPage()));}),
    );
  }
  void showCart(BuildContext ctx)=>showModalBottomSheet(context:ctx,isScrollControlled:true,builder:(_)=>SafeArea(child:Padding(padding:const EdgeInsets.all(18),child:Wrap(children:[
    const Text('Your cart',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    ...cart.entries.map((e)=>ListTile(title:Text(items[e.key].name),subtitle:Text('₹${items[e.key].price} × ${e.value}'),
      trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){setState(()=>cart.remove(e.key));Navigator.pop(ctx);}))),
    ListTile(title:const Text('Total'),trailing:Text('₹$total')),
    SizedBox(width:double.infinity,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:red),onPressed:()=>Navigator.push(ctx,MaterialPageRoute(builder:(_)=>const CheckoutPage())),child:const Text('Checkout')))
  ]))));
}

class CheckoutPage extends StatelessWidget {
 const CheckoutPage({super.key});
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Checkout')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
  const TextField(decoration:InputDecoration(labelText:'Delivery address')),
  const ListTile(leading:Icon(Icons.payments),title:Text('Cash on delivery')),
  const ListTile(leading:Icon(Icons.credit_card),title:Text('Online payment (gateway setup needed)')),
  const Spacer(),FilledButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Demo checkout. Configure backend and payment keys.'))),child:const Text('Place order'))
 ])));
}
class OrdersPage extends StatelessWidget {
 const OrdersPage({super.key});
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Order tracking')),body:const Center(child:Text('Placed → Packed → Shipped → Delivered')));
}
class AuthPage extends StatefulWidget {
 const AuthPage({super.key});
 @override State<AuthPage> createState()=>_AuthPageState();
}
class _AuthPageState extends State<AuthPage>{
 final email=TextEditingController(),password=TextEditingController();bool signup=false;String result='';
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(signup?'Sign up':'Login')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
  TextField(controller:email,decoration:const InputDecoration(labelText:'Email')),
  TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password')),
  FilledButton(onPressed:()async{try{if(signup){await FirebaseAuth.instance.createUserWithEmailAndPassword(email:email.text.trim(),password:password.text);}else{await FirebaseAuth.instance.signInWithEmailAndPassword(email:email.text.trim(),password:password.text);}setState(()=>result='Success');}catch(e){setState(()=>result='Firebase setup required: $e');}},child:Text(signup?'Create account':'Login')),
  TextButton(onPressed:()=>setState(()=>signup=!signup),child:Text(signup?'Already registered? Login':'New user? Sign up')),Text(result),
  const Text('Admin panel: enforce admin access with Firebase custom claims/server-side authorization.')
 ])));
}
